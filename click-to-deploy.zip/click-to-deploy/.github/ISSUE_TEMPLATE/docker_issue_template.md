---
name: Container images
about: Report an issue related to the Docker image
labels: kind/docker, needs-triage
---

**Category:**

Container images

**Type:**

- [ ] Bug
- [ ] Feature Request
- [ ] Process

---

<!-- 1. Please select the type of the issue from the list above. -->
<!-- 2. Please describe the issue below. -->
