---
name: Kubernetes apps
about: Report an issue related to the Kubernetes application
labels: kind/k8s, needs-triage
---

**Category:**

Kubernetes apps

**Type:**

- [ ] Bug
- [ ] Feature Request
- [ ] Process

---

<!-- 1. Please select the type of the issue from the list above. -->
<!-- 2. Please describe the issue below. -->
