package main

import (
	"net/http"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"

	"fmt"
	"os/exec"
	"runtime"
	"time"
)

func mariadbbackup(timestamp string) {
	out, err := exec.Command("/mariadb_backup.sh", timestamp).Output()
	if err != nil {
		mariadbackup.With(prometheus.Labels{"cluster_name": "my-env"}).Set(0)
		fmt.Println("Command Failed")
		fmt.Println(string(out[:]))
		fmt.Printf("%s", err)
	}
	mariadbackup.With(prometheus.Labels{"cluster_name": "my-env"}).Set(1)
	fmt.Println("Command Successfully Executed")
	output := string(out[:])
	fmt.Println(output)
}

func runbackup() {
	for {
		currentTime := time.Now()
		timestamp := currentTime.Format("2006-01-02_15-04")
		fmt.Println(timestamp)
		mariadbbackup(timestamp)

		//Sleep for 100 ms
		time.Sleep(1 * time.Minute)
	}
}

var (
	mariadbackup = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{
			Name: "MariaDB_Backup_Status",
			Help: "MariaDB backup job status",
		},
		[]string{
			// Which cluster name where backup is executed
			"cluster_name",
		})
)

func init() {
	// Metrics have to be registered to be exposed:
	prometheus.MustRegister(mariadbackup)

}

func main() {

	if runtime.GOOS == "windows" {
		fmt.Println("Can't Execute this on a windows machine")
	} else {
		go runbackup()
	}

	// The Handler function provides a default handler to expose metrics
	// via an HTTP server. "/metrics" is the usual endpoint for that.
	http.Handle("/metrics", promhttp.Handler())
	http.ListenAndServe(":3112", nil)

}

