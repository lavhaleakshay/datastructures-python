#!/bin/bash

if [[ $(find /*.sql.gz -mtime +5) ]]
then
    find /*.sql.gz -mtime +5 -print -exec rm -f {} \;
else
    echo "No backup files more than 5 days of age to del"
fi

BKP_NAME="all-databases-$(date "+%F_%H-%M").sql.gz"
BKP_DIR=var/mariadb/backup
POD_NAME=mariadb-0
NAMESPACE=default

# Backup database
echo "Backup Started"
kubectl -n ${NAMESPACE} exec -it ${POD_NAME}  -- bash -c -C "mkdir -p ${BKP_DIR} && mysqldump --all-databases --triggers --routines --events --add-drop-table --single-transaction --ignore-table=mysql.user -uroot -pbLgMB5q4fWlU | gzip > ${BKP_DIR}/${BKP_NAME}"
echo "Backup Done"
# Copy backup file to local workstation and cleanup Pod
echo "Copying Backup on localmachine"
kubectl cp ${NAMESPACE}/${POD_NAME}:${BKP_DIR}/${BKP_NAME} ${BKP_NAME}
echo "Deleting backup files from mariadb pod"
kubectl -n ${NAMESPACE} exec -it ${POD_NAME} -- bash -c -C "rm -f ${BKP_DIR}/${BKP_NAME}"
echo "Deletion completed"
